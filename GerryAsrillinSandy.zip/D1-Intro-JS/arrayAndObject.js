// const pets = ["cat", "dog", "canary", "turtle"];

// console.log(pets);
// console.log(pets[1]);

// for (var i = 0; i < pets.length; i++) {
//   console.log(pets[i]);
// }

// for (let index in pets) {
//   console.log(pets[index]);
// }

// const person = {
//   name: "John Doe",
//   age: 30,
//   profession: "Developer",
// };

// const students = [
//   { name: "John", age: 20, grade: "A" },
//   { name: "Jane", age: 19, grade: "B" },
//   { name: "Sam", age: 21, grade: "A+" },
//   { name: "Emily", age: 18, grade: "B+" },
// ];

// const myStudent = students.map(function (student) {
//   return student.name;
// });

// console.log(myStudent);
