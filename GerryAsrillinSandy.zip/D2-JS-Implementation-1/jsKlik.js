var myButton = document.getElementById("myButton");

myButton.addEventListener("click", myFunction);

function myFunction() {
  alert("Tombol Sudah DI Klik!");
}
