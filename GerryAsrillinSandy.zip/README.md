- 👋 Hi, I’m @GerryAsrillinSandy
- 👀 I’m interested in Fullstack Development, Devops, AI/ML, and Data Scienth.
- 🌱 I’m currently learning DBMS, Phyton, JS, etc.
- 💞️ I’m looking to collaborate on Developer Community
- 📫 How to reach me gerryasrillinsandy@gmail.com

<!---
GerryAsrillinSandy/GerryAsrillinSandy is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
