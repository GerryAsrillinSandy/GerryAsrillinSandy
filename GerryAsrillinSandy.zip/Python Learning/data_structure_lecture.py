""" first_name = 'josh'
last_name = 'thomas'
age = 17
gender = 'male'

print(first_name)
 """

"""
first_name, last_name, age = 'Julia', 'Aluna', 20
"""

""" first_name = input('What is your first name: ')
last_name = input('What is your last name: ')
age = int(input('How old are you: ')) """

""" def my_function(x):
    return 5 * x

print(my_function(3))
print(my_function(5))
print(my_function(9)) """

import numpy as np


repeat_array = np((4, 3), [1,2,3], dtype=int)
print (repeat_array)