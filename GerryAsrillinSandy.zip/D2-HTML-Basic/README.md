# D2-HTML-Basic

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/web-platform-xieoj7)